﻿namespace Hospital_Management.Models.EntitiesDto
{
    public class RefreshTokenDto
    {
        public string Token { get; set; }
      
    }
}
